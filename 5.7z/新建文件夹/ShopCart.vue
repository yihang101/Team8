<template>
  <div>
    <div class="button2">
      <el-button type="primary" class="shoucang" @click="goback">返回</el-button>
    </div>
    <el-table
      :data="tableData"
      border
      style="width: 82%"
      @selection-change="selected"
    >
      <el-table-column
        type="selection"
        width="50"
      />
      <el-table-column
        label="商品名称"
        width="680"
      >
        <template scope="scope">
          <div style="margin-left: 50px">
            <img :src="scope.row.url" style="height: 50px;width: 50px">
            <span style="font-size: 18px;padding-left: 200px;">{{ scope.row.name }}</span>
          </div>
        </template>
      </el-table-column>
      <el-table-column
        label="单价"
        width="150"
        prop="price"
      />
      <el-table-column
        label="数量"
        width="200"
      >
        <template scope="scope">
          <div>
            <el-input
              v-model="scope.row.buynum"
              @change="handleInput(scope.row)"
            >
              <el-button slot="prepend" @click="del(scope.row)"><i class="el-icon-minus" /></el-button>
              <el-button slot="append" @click="add(scope.row)"><i class="el-icon-plus" /></el-button>
            </el-input>
          </div>
        </template>
      </el-table-column>
      <!--  <el-table-column
        label="小计"
        width="150"
        prop="goodTotal"
      /> -->
      <el-table-column label="操作">
        <template scope="scope">
          <el-button type="danger" @click="handleDelete(scope.row.number)">
            删除<i class="el-icon-delete2 el-icon--right" />
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <br>
    <!-- <el-button type="info" style="float: right">{{ "商品总额：" + moneyTotal }}</el-button> -->
  </div>
</template>

<script>
import request from '/src/config/request.js'
export default {
  data() {
    return {
      custid: '',
      tableData: [
        { id: '',
          url: 'http://i1.mifile.cn/a1/pms_1474859997.10825620!80x80.jpg',
          information: '小米手环2',
          price: 149,
          buynum: 1
          // goodTotal: 149
        }],
      moneyTotal: 0,
      multipleSelection: []
    }
  },
  mounted() {
    this.custid = this.$session.get('custid')
    request.get(`/api/buycar/getbuycar/${this.custid}`).then(res => {
      console.log(res)
      this.tableData = res
    })
  },
  methods: {
    handleDelete(id) {
      this.$confirm('确定删除该商品？', '提示', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        request.delete(`/api/buycar/cancelbuycar/${id}`).then(res => {})
        request.get(`/api/buycar/getbuycar/${this.custid}`).then(res => {
          console.log(res)
          this.tableData = res
        })
        // 删除数组中指定的元素
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
      }).catch(() => {
        this.$message({
          type: 'info',
          message: '已取消删除'
        })
      })
    },
    handleInput: function(value) {
      if (value.number == null || value.number === '') {
        value.number = 1
      }
      value.goodTotal = (value.number * value.price).toFixed(2)// 保留两位小数
      // 增加商品数量也需要重新计算商品总价
      this.selected(this.multipleSelection)
    },
    add: function(addGood) {
      // 输入框输入值变化时会变为字符串格式返回到js
      // 此处要用v-model，实现双向数据绑定
      if (typeof addGood.number === 'string') {
        addGood.number = parseInt(addGood.number)
      }
      addGood.number += 1
    },
    goback() {
      this.custid = this.$route.query.custid
      this.$router.push({
        path: '/Sell/Custlishi',
        query: {
          custid: this.custid
        }
      })
    },
    del: function(delGood) {
      if (typeof delGood.number === 'string') {
        delGood.number = parseInt(delGood.number)
      }
      if (delGood.number > 1) {
        delGood.number -= 1
      }
    },
    // 返回的参数为选中行对应的对象
    selected: function(selection) {
      this.multipleSelection = selection
      this.moneyTotal = 0
      // 此处不支持forEach循环，只能用原始方法了
      for (var i = 0; i < selection.length; i++) {
        // 判断返回的值是否是字符串
        if (typeof selection[i].goodTotal === 'string') {
          selection[i].goodTotal = parseInt(selection[i].goodTotal)
        }
        this.moneyTotal += selection[i].goodTotal
      }
    } }

}
</script>
